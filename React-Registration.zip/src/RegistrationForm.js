import React from 'react';
import './style.css'; 

function RegistrationForm() {
  return (
    <div className="container">
        <form onSubmit={validateForm}>
            <div className="header">
                <h1>Create User</h1>
            </div>
            
            <div className="input-row">
                <label htmlFor="first-name">First name</label>
                <input type="text" id="first-name" placeholder="Enter your First name" required />
            </div>
            
            <div className="input-row">
                <label htmlFor="last-name">Last name</label>
                <input type="text" id="last-name" placeholder="Enter your Last name" required /> 
            </div>
            
            <div className="input-row">
                <label htmlFor="username">Username</label>
                <input type="text" id="username" placeholder="Enter your username" required /> 
            </div>
            
            <div className="input-row">
                <label htmlFor="email" className="email">Email id </label>  
                <input type="email" id="email" placeholder="Enter your Email id" required />
            </div>
            
            <div className="input-row">
                <label htmlFor="password" className="password">Password </label>  
                <input type="password" id="password" placeholder="Enter your password" pattern="^(?=.*\d)(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9])\S{8,}$"
                required />
            </div>
            
            <div className="input-row">
                <label htmlFor="confirm-password" className="password">Confirm Password </label>  
                <input type="password" id="confirm-password" placeholder="Confirm your password" required />
                <span id="password-error" style={{color: 'rgb(124, 33, 33)', display: 'none'}}>Passwords do not match</span>
            </div>
            <div className="input-row">
                <label htmlFor="dob" className="dob">DOB</label>  
                <input type="date" id="dob" placeholder="Enter your date of birth" required />
            </div>
            
            <div className="input-row radio-row">
                <label>Gender</label>
                <input type="radio" id="male" name="gender" value="male" />
                <label htmlFor="male">Male</label>
                <input type="radio" id="female" name="gender" value="female" />
                <label htmlFor="female">Female</label>
            </div>
            
            <div className="input-row">
                <label htmlFor="country">Country</label>
                <select id="country" name="country">
                    <option value="#" selected disabled>Select</option>
                    <option value="#">India</option>
                    <option value="#">USA</option>
                    <option value="#">Russia</option>
                    <option value="#">UK</option>
                    <option value="#">UAE</option>
                    <option value="#">Australia</option>
                </select>
            </div>
            
            <input type="checkbox" value="yes" />
            <label htmlFor="terms">I have read and accept the <a href="terms.html">terms and conditions</a></label>
            <p>Already have an account <a href="login.html">click here</a></p>
            
            <div className="btn">
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>
  );
}

function validateForm(event) {
    event.preventDefault(); 
        
    var firstName = document.getElementById("first-name").value.trim();
    var lastName = document.getElementById("last-name").value.trim();
    var username = document.getElementById("username").value.trim();
    var email = document.getElementById("email").value.trim();
    var country = document.getElementById("country").value.trim();
    var dob = document.getElementById("dob").value.trim();
    var gender = document.querySelector('input[name="gender"]:checked');
    var termsAgreed = document.querySelector('input[type="checkbox"]:checked');

    if(firstName === "" || lastName === "" || username === "" || email === "" || country === "" || dob === "" || !gender || !termsAgreed) {
        alert("Please fill all the required fields");
        return false;
    }

    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirm-password").value;
    var passwordError = document.getElementById("password-error");

    if (password !== confirmPassword) {
        passwordError.style.display = "block";
        return false;
    } else {
        passwordError.style.display = "none";

        let passwordRegex = /^(?=.*\d)(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9])\S{8,}$/;

        if (!passwordRegex.test(password)) {
            alert(
                "Password must be at least 8 characters long and include at least one number, one alphabet, and one symbol."
            );
            return false;
        }

        var user = {
            firstName: firstName,
            lastName: lastName,
            username: username,
            email: email,
            country: country,
            dob: dob,
            gender: gender.value,
            password: password  
        };

        localStorage.setItem('user', JSON.stringify(user));
        alert("Registration successful!");
        
        return false; 
    }
}

export default RegistrationForm;
